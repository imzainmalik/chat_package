
<?php

return [
    'max_file_size' => 10240,
    'allowed_files' => ['jpg','png','pdf','mp3','mp4','docx'],
];
