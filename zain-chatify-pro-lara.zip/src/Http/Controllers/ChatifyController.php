<?php

namespace ChatifyPro\Http\Controllers;

use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Auth;

class ChatifyController extends Controller
{
    public function index()
    { 
        return view('chatify::pages.app', [
            'user' => Auth::user(),
            'pusherKey' => config('broadcasting.connections.pusher.key'),
            'pusherCluster' => config('broadcasting.connections.pusher.options.cluster'),
        ]);
    }
}