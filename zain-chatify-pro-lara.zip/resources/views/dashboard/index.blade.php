
@extends('layouts.app')
@section('content')
<div class="container">
    <h3>Chatify Dashboard</h3>
</div>
@endsection
