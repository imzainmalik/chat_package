
@extends('layouts.app')
@section('content')
<div class="container">
    <h3>Chatify Pro</h3>
    <div id="chat-box"></div>
</div>
@endsection
